package com.MentorOnDemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MentorOnDemand.Repository.AdminDao;
import com.MentorOnDemand.Repository.SkillsDao;
import com.MentorOnDemand.model.Admin;
import com.MentorOnDemand.model.Login;
import com.MentorOnDemand.model.Skills;
@Service
public class AdminServiceImpl implements AdminService {
@Autowired
AdminDao adminDao;
@Autowired
SkillsDao skillsDao;
	@Override
	public List<Admin> findByEmail(String username) {
		
		return adminDao.findByEmail(username);
	}
	@Override
	public void insertSkill(Skills skill) {
		skillsDao.save(skill);
	}

}
