package com.MentorOnDemand.Controller;

import java.sql.SQLException;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

import com.MentorOnDemand.Repository.ProposeDao;

import com.MentorOnDemand.model.ProposalRequest;

@Controller
public class MentorController {
	@Autowired
	ProposeDao prDao;

	@RequestMapping(value = "/notification")
	public ModelAndView notificatons(ModelMap map) throws SQLException {
		ModelAndView mv = new ModelAndView();
		List<ProposalRequest> proposal = prDao.findAll();

		map.addAttribute("notificationList", proposal);

		mv.setViewName("ProposalList");
		return mv;
	}
}
