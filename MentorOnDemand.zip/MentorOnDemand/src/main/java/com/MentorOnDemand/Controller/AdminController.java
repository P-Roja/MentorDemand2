package com.MentorOnDemand.Controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.MentorOnDemand.Repository.AdminDao;
import com.MentorOnDemand.Repository.MentorDao;
import com.MentorOnDemand.Repository.ProposeDao;
import com.MentorOnDemand.model.Login;
import com.MentorOnDemand.model.Mentor;
import com.MentorOnDemand.model.ProposalRequest;
import com.MentorOnDemand.model.Skills;
import com.MentorOnDemand.service.AdminService;
import com.MentorOnDemand.service.MentorService;
import com.MentorOnDemand.service.UserService;

@Controller
public class AdminController {
	@Autowired
	AdminService adminService;
	@Autowired
	UserService userService;
	@Autowired
	MentorService mentorService;
	@Autowired
	MentorDao mentorDao;

	@Autowired
	ProposeDao prDao;

	@RequestMapping("/addSkill")
	public ModelAndView addSkill(ModelMap map) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("skill", new Skills());
		mav = new ModelAndView("AddSkill");
		return mav;

	}

	@RequestMapping(path = "/searchMentor")
	public ModelAndView getMentorUserList(ModelMap map, @ModelAttribute("mentor") @Valid Mentor mentor,
			HttpServletRequest request, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();

		ArrayList<Skills> skillList = userService.getSkillList();
		map.addAttribute("mentor", new Mentor());
		map.addAttribute("skillsList", skillList);
		List<Mentor> mentorList = mentorDao.findBySkills(mentor.getSkills());
		mv.addObject("mentorList", mentorList);
		mv.setViewName("DisplayMentor");

		return mv;
	}

	@RequestMapping(path = "/searchAdminMentor")
	public ModelAndView getMentorList(ModelMap map, @ModelAttribute("mentor") @Valid Mentor mentor,
			HttpServletRequest request, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();

		List<Mentor> mentorList = mentorDao.findBySkillsAndSlotTime(mentor.getSkills(), mentor.getSlotTime());
		System.out.println(mentorList);
		if (mentorList.isEmpty()) {
			mv.setViewName("NoMentor");
		} else {
			mv.addObject("mentorList", mentorList);
			mv.setViewName("AdminSearch");
		}

		return mv;
	}

	@RequestMapping(value = "/addSkill", method = RequestMethod.POST)
	public ModelAndView insertSkill(@ModelAttribute("skill") @Valid Skills skill, BindingResult result,
			HttpServletRequest request, ModelMap map) throws SQLException {
		ModelAndView mav = null;

		if (result.hasErrors()) {
			mav = new ModelAndView("AddSkill");
			return mav;
		}
		adminService.insertSkill(skill);
		ArrayList<Skills> skillList = userService.getSkillList();
		map.addAttribute("mentor", new Mentor());
		map.addAttribute("skillsList", skillList);
		System.out.println(skillList);
		mav = new ModelAndView("UserLandingPage");
		return mav;

	}

	@RequestMapping(value = "/proposeTraining")
	public ModelAndView proposeTraining(@RequestParam("id") long id, @RequestParam("userId") long userId,
			@ModelAttribute("mentor") @Valid Mentor mentor, ModelMap map) throws SQLException {
		ModelAndView mav = null;
       List<ProposalRequest> proposal = prDao.findByUserIdAndMentorId(id, userId);
       if(proposal.isEmpty())
       {ProposalRequest pr = new ProposalRequest();
		pr.setMentorId(id);
		pr.setUserId(userId);
		/*
		 * pr.setStatus("approve"); pr.setTechnologyId(1);
		 */
		prDao.save(pr);
       }
       else
       {
    	   System.out.println("Empty");
       
       }
		ModelAndView mv = new ModelAndView();

		ArrayList<Skills> skillList = userService.getSkillList();
		map.addAttribute("mentor", new Mentor());
		map.addAttribute("skillsList", skillList);
		List<Mentor> mentorList = mentorDao.findBySkills(mentor.getSkills());
		mv.addObject("mentorList", mentorList);
		mv.setViewName("DisplayMentor");
return mv;
	}
}
