package com.MentorOnDemand.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.MentorOnDemand.model.ProposalRequest;

public interface ProposeDao extends JpaRepository<ProposalRequest, Long>{

	
	@Query(value = "SELECT proposal FROM ProposalRequest proposal WHERE proposal.userId=?1 and proposal.mentorId=?2")
	List<ProposalRequest> findByUserIdAndMentorId(long userId, long mentorId);
}
