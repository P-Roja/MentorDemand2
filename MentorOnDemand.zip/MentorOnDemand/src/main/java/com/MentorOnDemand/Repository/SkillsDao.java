package com.MentorOnDemand.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MentorOnDemand.model.Login;
import com.MentorOnDemand.model.Skills;

public interface SkillsDao extends JpaRepository<Skills, Integer>{

}
